package com.technews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechNewsJavaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
